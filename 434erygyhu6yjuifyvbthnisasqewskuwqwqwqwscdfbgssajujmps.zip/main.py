#Importing
from replit import db
from threading import Thread
user=""
db.db_url = "https://kv.replit.com/v0/eyJhbGciOiJIUzUxMiIsImlzcyI6ImNvbm1hbiIsImtpZCI6InByb2Q6MSIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJjb25tYW4iLCJleHAiOjE2MzgxODA3MTIsImlhdCI6MTYzODA2OTExMiwiZGF0YWJhc2VfaWQiOiIyNDYzNGM5Ni00ZmUyLTRkZTMtOGY1ZS03NTg0OTE2YWM1YjQifQ.jK6kCTPLy6RiRvP2-nkHjtgFVTUpqOn_cOmxpK_8oUpyAoqX53OLSx_-wNtHO0qNKCrt8-IYFZhD69-T2SQnLA"
from flask import Flask, redirect, url_for, render_template, request

app = Flask(__name__)


#Pranav Sai: Main Page
@app.route("/", methods=["POST", "GET"])
def home():
  global user
  if request.method == "POST":
    user = request.form["username"]
    p = request.form["password"]
    if db[user][0]==p:
      username=user
      password=p
      return render_template("pranavsai.html",un=username)
    else:
      return "Sorry,your Username or Password did not match the records."
  else:
    return render_template("index.html")


#Magnitudo
@app.route("/magnitudo.html",methods=["POST","GET"])
def magnitudo():
  return render_template("magnitudo.html",un1=user)
#MagnitudoChat
@app.route("/chat.html",methods=["POST","GET"])
def mchat():
  return render_template("chat.html",un2=user)


#About Me
@app.route("/about.html",methods=["POST","GET"])
def about():
  return render_template("about.html")
#Search
@app.route("/search.html",methods=["POST","GET"])
def search():
  return render_template("search.html")
#Thankyou
@app.route("/<usr>")
def user(usr):
  return f"<h1>{usr}</h1>"


#Running Flask App
def run():
  app.run(host='0.0.0.0', port=8080)
#Keey Alive
def keep_alive():  
    t = Thread(target=run)
    t.start()
keep_alive()